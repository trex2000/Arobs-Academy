/******************************************************************************
 * FunctionName : espconn_init
 * Description  : dummy the espconn_init
 * Parameters   : none
 * Returns      : none
*******************************************************************************/
void espconn_init()
{
	// dummy function, do nothing.
}
