## Contributing

Thank you everyone for contributing to this project.

Pull requests for new features and major fixes should be opened against the `dev` branch.

*Note that the `pre_build` bin in the dev branch is never up-to-date.*
